package com.springrest.springrestv.controller;


//this file acts as presentation layer/controllers  - >>from here control gets transfer to services layer 

//43.35 min - learncode with durgesh (part 1)
/*
 <dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-data-jpa</artifactId>
		</dependency>
		
		
		//the above dependency is restored in part 2 of video at 15.17 min
 */
import java.util.List;
//import java.util.stream.Stream;

import org.omg.PortableServer.THREAD_POLICY_ID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrestv.entity.Course;
import com.springrest.springrestv.services.CourseService;

import net.bytebuddy.asm.Advice.Return;
import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Employee;

@RestController
public class MyController {
	@Autowired
	private CourseService courseService;

	//test route controller
	@GetMapping("/vickytest")
	public String myMethod()
	{
		return this.courseService.test();
	}
	
	@GetMapping("/tappu")
	public String tap()
	{
		return "god bless you";
	}
	
	//get all courses
	@GetMapping("/api/courses")
	@CrossOrigin(origins = "http://localhost:3000")
	public List<Course> getAllCourses()
	{
		//Stream<Integer> stream = 
		return this.courseService.getCourses();
	}
	
	//alternative to above route is following route technique
	
	//@RequestMapping(path="/courses",method=RequestMethod.GET)
	//public List<Course> getCourses()
	//{
	 //return this.courseService.getCourses();
	//}
	
//	get one course by its id
	@GetMapping("/course/{courseId}")
	@CrossOrigin(origins = "http://localhost:3000")
	public Course getCourse(@PathVariable long courseId)
	{
//		System.out.println("******************"+courseId);
		return this.courseService.getOneCourse(courseId);
	}
	
//	@GetMapping("/course/{courseId}")
//	public ResponseEntity<Course> getEmployeeById(@PathVariable Long courseId) {
//		ResponseEntity<Course> employee = this.courseService.getOneCourse(courseId);
////				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
//		return employee;
//	}
	
	
	//add new course
	@PostMapping("/course")
	@CrossOrigin(origins = "http://localhost:3000")
	public Course addCourse(@RequestBody Course course)
	{
		System.out.println("******************"+course);
		return this.courseService.addNewCourse(course);
	}
	
	//update course by passing its id in url
	@PutMapping("/course/{courseId}")
	@CrossOrigin(origins = "http://localhost:3000")
	public Course updateCourse(@PathVariable String courseId,@RequestBody Course course)
	{
		System.out.println("************FROM UPDATE******"+courseId);
		return this.courseService.updateCourse(Long.parseLong(courseId), course);
	}
	
	//delete one course by passing its id in url
	@DeleteMapping("/course/{courseId}")
	@CrossOrigin(origins = "http://localhost:3000")
	public ResponseEntity<HttpStatus> deleteCourse(@PathVariable String courseId)
	{
		try {
			this.courseService.deleteCourse(Long.parseLong(courseId));
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<HttpStatus>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	
	
	
}
