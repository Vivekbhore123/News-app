package com.springrest.springrestv.services;


//this file is part of service layer ->>from here control gets transferred to dao layer (repository layer)
//actual logic is present in this layer
//layer can be considered as package in this project

import java.util.List;

//import org.springframework.http.ResponseEntity;

import com.springrest.springrestv.entity.Course;

public interface CourseService {
	
	public String test();
	
	public List<Course> getCourses();
	
	public Course getOneCourse(long courseId);
	
	public Course addNewCourse(Course course);
	
	public Course updateCourse(long courseId,Course course);
	
	public Course deleteCourse(long courseId);
}
