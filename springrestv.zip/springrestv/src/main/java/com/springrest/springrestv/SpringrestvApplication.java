package com.springrest.springrestv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestvApplication.class, args);
	}

}
