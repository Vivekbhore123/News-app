package com.springrest.springrestv.dao;


//this file is a part of dao layer, this file directly interact with database and sends it to service layer

import org.springframework.data.jpa.repository.JpaRepository;

import com.springrest.springrestv.entity.Course;

public interface CourseDao extends JpaRepository<Course,Long> {

}
