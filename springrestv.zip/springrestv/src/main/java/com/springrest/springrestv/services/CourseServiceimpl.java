package com.springrest.springrestv.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;

import com.springrest.springrestv.dao.CourseDao;
import com.springrest.springrestv.entity.Course;

//this file is part of service layer ->>from here control gets transferred to dao layer (repository layer)
//actual logic is present in this layer
//layer can be considered as package in this project

@Service
public class CourseServiceimpl implements CourseService {
	
//	List<Course> list;
	
	@Autowired
	private CourseDao courseDao;
	
//	public CourseServiceimpl() {
//		list = new ArrayList<Course>();
//		list.add(new Course(123,"java","this is full stack"));
//		list.add(new Course(122,"success","success is byproduct of failure"));
//	}

//	public List<Course> getCourses() {
//		return list;
//	}
	
	public List<Course> getCourses() {
		return courseDao.findAll();
	}

//	public Course getOneCourse(long courseId) {
//		Course c = null;
//		for(Course course:list)
//		{
//			if(courseId==course.getId())
//			{
//				c = course;
//				break;
//			}
//		}
//		return c;
//
//	}
	
	
//	@SuppressWarnings("deprecation")
	public Course getOneCourse(long courseId) {
		System.out.println(courseId+"&************###################################");
		Course obj = courseDao.findById(courseId).get();
        return obj;

	}

	public Course addNewCourse(Course course) {
//		list.add(course);
		courseDao.save(course);
		return course;
	}
	
//	public List<Course> updateCourse(long courseId,Course coursenew) {
//		
//		int k=0;
//		for(Course course:list)
//		{
//			
//			
//			if(courseId==course.getId())
//			{
//				list.set(k,coursenew);
//				break;
//			}
//			k=k+1;
//		}
//		return list;
//	
//
//	}
	
public Course updateCourse(long courseId,Course coursenew) {
  		
	    courseDao.save(coursenew); 	
		return coursenew;
	

	}
	
//	public List<Course> deleteCourse(long courseId)
//	{
//		int m=0;
//		for(Course c:list)
//		{
//			if(c.getId()==courseId)
//			{
//				list.remove(m);
//				break;
//			}
//			m++;
//		}
//		return list;
//	}

@SuppressWarnings("deprecation")
public Course deleteCourse(long courseId)
{
	Course entity = courseDao.getOne(courseId);
	courseDao.delete(entity);
	return entity;
}


public String test() {
		String str = new String("vivek bhore testing app lets crack it");
	return str;
}

//	public String test() {
//		
//		return list.get(0).toString();
//	}
	
	

}
