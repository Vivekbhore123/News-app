import React from"react";
import {BrowserRouter,Routes,Route,Link } from "react-router-dom";
import About from "./component/About";
import Contact from "./component/Contact";
import Courses from "./component/Courses";
import Home from "./component/Home";
import Showonecourse from "./component/ShowOneCourse";




      
const MainRoutes = ()=>{
  return(

<BrowserRouter>

        <Routes>
          <Route index element={<Home />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/course/:id" element={<Showonecourse />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          
        </Routes>
      
  </BrowserRouter>

)
}

export default MainRoutes;

// <nav>
// <ul>
//   <li>
//     <Link to="/">Home</Link>
//   </li>
//   <li>
//     <Link to="/about">About</Link>
//   </li>
//   <li>
//     <Link to="/users">Users</Link>
//   </li>
// </ul>
// </nav>