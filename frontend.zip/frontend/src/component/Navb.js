import React from "react";

import { Navbar,Collapse,DropdownMenu,DropdownToggle,NavbarToggler,Nav,NavbarText,DropdownItem,NavbarBrand,NavItem,NavLink,UncontrolledDropdown } from "reactstrap";

const Navb = () => {
  return (
    <div>
      <Navbar color="light" expand="md" light>
              <hr />
        <NavbarBrand href="/">MadeByVivek</NavbarBrand>
        <NavbarToggler onClick={function noRefCheck() {}} />
        <Collapse navbar>
          <Nav className="me-auto" navbar>
            <NavItem>
              <NavLink href="/courses/">Courses</NavLink>
            </NavItem>

            <NavItem>
              <NavLink href="/about/">About Us</NavLink>
            </NavItem>

            <NavItem>
              <NavLink href="/contact/">Contact Us</NavLink>
            </NavItem>

            {/* <NavItem>
              <NavLink href="https://github.com/reactstrap/reactstrap">
                GitHub
              </NavLink>
            </NavItem> */}
            {/* <UncontrolledDropdown inNavbar nav>
              <DropdownToggle caret nav>
                Options
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem>Option 1</DropdownItem>
                <DropdownItem>Option 2</DropdownItem>
                <DropdownItem divider />
                <DropdownItem>Reset</DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown> */}
          </Nav>
          <NavbarText style={{cursor:"pointer"}}>Log-out</NavbarText>
        </Collapse>
      </Navbar>
    </div>
  );
};

export default Navb;
