import React from 'react';

const Contact = () => {
        return (
                <div>
                  <h1>This is contact us page</h1>
                </div>
        );
}

export default Contact;
