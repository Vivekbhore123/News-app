import React, { useState, useEffect } from "react";
import axios from "axios";

import { useParams } from "react-router-dom";

import {
  Card,
  CardBody,
  CardTitle,
  CardText,
  CardSubtitle,
  Button,
  Row,
  Col,
  InputGroup,
  InputGroupText,
  Input,
} from "reactstrap";

const Showonecourse = () => {
  const url = "http://localhost:8080";

  const { id } = useParams();

  const [singleCourse, setSingleCourse] = useState({});
  const [isUpdateButtonClicked, setIsUpdateButtonClicked] = useState(true);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  function doIt(e) {
    //      alert(e);
    //    console.log(e.target)
    setTitle(e.target.value);
  }

  function doItForDescription(e) {
    // alert(e.taget);
    // console.log(e.target)
    setDescription(e.target.value);
  }

  async function submitInfo(id) {
    await axios
      .put(`http://localhost:8080/course/${id}`, {
        id:id,      
        courseName: title,
        description: description,
      })
      .then((res) => {
        console.log("course added successfully", res);
        window.location = "http://localhost:3000/courses";
      })
      .catch((e) => console.log("error occured", e));
    console.log(title);
    console.log(description);
  }

  useEffect(() => {
    // alert(id);
    const fetchSingleCourse = async () => {
      await axios
        .get(`${url}/course/${id}`)
        .then((res) => {
          console.log(res);
          setSingleCourse(res.data);
          setTitle(res.data.courseName);
          setDescription(res.data.description);
        })
        .catch((err) => console.log(err));
    };
    fetchSingleCourse();
  }, []);


  async function deleteOneCourse()
  {
        await axios
        .delete(`${url}/course/${id}`)
        .then((res) => {
          console.log(res);
          window.location = "http://localhost:3000/courses";

        })
        .catch((err) => console.log(err));    
  }

  return (
    <div>
      <h1>
        Surprise motherfuckers - <span>{id}</span>
      </h1>

      {(singleCourse && isUpdateButtonClicked) ? (
        <>
          <h1>{singleCourse.id}</h1>
          <h1>{singleCourse.courseName}</h1>
          <h1>{singleCourse.description}</h1>
          <div>
            <Button onClick={()=>setIsUpdateButtonClicked(!isUpdateButtonClicked)}>Update</Button>{" "}
            {"        "}
            <Button onClick={()=>deleteOneCourse()}>Delete</Button>
          </div>
        </>
      ) : (
        <div
          style={{
            width: "70%",
            backgroundColor: "blueviolet",
            marginLeft: "15%",
            marginTop: "8%",
            border: "5px solid white",
          }}
        >
          <h3 className="text-white">Update Course</h3>

          <form action="" style={{ padding: "30px" }}>
            <InputGroup>
              <Input
                placeholder="Course Title"
                type="text"
                onChange={doIt}
                value={title}
              />
              {/* <InputGroupText>
                                   @example.com
                                 </InputGroupText> */}
            </InputGroup>
            <br />
            <InputGroup>
              <Input
                placeholder="Description"
                type="textarea"
                onChange={doItForDescription}
                value={description}
              />
              {/* <InputGroupText>
                                 </InputGroupText> */}
            </InputGroup>
            <br />

            <Button className="btn btn-success" onClick={()=>submitInfo(singleCourse.id)}>
              Update course
            </Button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Showonecourse;
