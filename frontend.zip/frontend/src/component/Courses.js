import React, { useState, useEffect } from "react";
import { Container, Row } from "reactstrap";
import axios from "axios";


import {
  Card,
  CardBody,
  CardTitle,
  CardText,
  CardSubtitle,
  Button,
} from "reactstrap";

const Courses = () => {
  const [courseList, setCourseList] = useState([]);

  const url = "http://localhost:8080";

  useEffect(() => {
    const fetchCourses = async () => {
      await axios
        .get(`${url}/api/courses`)
        .then((res) => {
          console.log(res);
          setCourseList(res.data);
        })
        .catch((err) => console.log(err));
    };
    fetchCourses();
  }, []);


  function getOneCourse(id)
  {
    
     
          window.location = `http://localhost:3000/course/${id}`
    }

  return (
    <div>
      <Container width="100%">
        <Row>
          {courseList.length > 0 ? (
            <>
              {courseList.map((item,index) => {
                return (
                  <Card
                    style={{ backgroundColor: "red",cursor:"pointer" }}
                    className="m-5 text-white"
                    key={index}
                    onClick={()=>getOneCourse(item.id)}
                  >
                    <CardBody>
                      <CardTitle tag="h5">{item.courseName}</CardTitle>
                      <CardSubtitle className="mb-2" tag="h6">
                        Course ID - <span>{item.id}</span>
                      </CardSubtitle>
                      <CardText>{item.description}</CardText>
                     
                    </CardBody>
                  </Card>
                );
              })}
            </>
          ) : (
            <h1>Courses not found</h1>
          )}
        </Row>
      </Container>
    </div>
  );
};

export default Courses;
