import React,{useState} from "react";

import {
  Card,
  CardBody,
  CardTitle,
  CardText,
  CardSubtitle,
  Button,
  Row,
  Col,
  InputGroup,
  InputGroupText,
  Input,
} from "reactstrap";

import { useNavigate } from "react-router-dom";
import axios from "axios";


const Home = () => {
  let history = useNavigate();

  const [title,setTitle] = useState("");
  const [description,setDescription] = useState("");

  function handleClick() {
    history("/courses");
  }

   function doIt(e){
//      alert(e);
//    console.log(e.target)
   setTitle(e.target.value);
   }

   function doItForDescription(e){
        // alert(e.taget);
        // console.log(e.target)
        setDescription(e.target.value)
      }

   
    async function submitInfo()
    {
      await axios.post("http://localhost:8080/course",{courseName:title,description:description})
      .then((res)=>{
        console.log("course added successfully",res);
        window.location="http://localhost:3000/courses"
      })
      .catch((e)=>console.log("error occured",e))
            console.log(title);
            console.log(description);
    }
       

  return (
    <div>
      <>
      <div style={{height:"50px"}}></div>
        <div>
          <Row>
          <Col sm="1" ></Col>
            <Col sm="5" >
              <Card body style={{backgroundColor:"#CAD5E2"}}>
                <CardTitle tag="h5">Special Title Treatment</CardTitle>
                <CardText>
                  With supporting text below as a natural lead-in to additional
                  content.
                </CardText>
                <Button onClick={handleClick}>Explore free courses</Button>
              </Card>
            </Col>
            <Col sm="5">
              <Card body>
                <CardTitle tag="h5">Special Title Treatment</CardTitle>
                <CardText>
                  With supporting text below as a natural lead-in to additional
                  content.
                </CardText>
                <Button onClick={handleClick}>Get access to premium content</Button>
              </Card>
            </Col>
          </Row>
        </div>

        <div>
        <div>
 
  
  <br />

  <div style={{width:"70%",backgroundColor:"blueviolet",marginLeft:"15%",marginTop:"8%",border:"5px solid white"}}>

   <h3 className="text-white">Add New Course</h3>

  <form action="" style={{padding:"30px"}}>
  <InputGroup>
    <Input placeholder="Course Title" type="text" onChange={doIt} value={title} />
    {/* <InputGroupText>
      @example.com
    </InputGroupText> */}
  </InputGroup>
  <br />
  <InputGroup>
    <Input placeholder="Description" type="textarea" onChange={doItForDescription} value={description} />
    {/* <InputGroupText>
    </InputGroupText> */}
  </InputGroup>
  <br />


  <Button className="btn btn-success" onClick={submitInfo}>Add course</Button>

  </form>
  </div>
 
  
</div>
        </div>
      </>
    </div>
  );
};

export default Home;
