import {Button} from "reactstrap";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import MainRoutes from "./MainRoutes";
import Navb from "./component/Navb";



function App() {


  const notify = () => toast.success("dome");


  return (
    <div>
      <Navb/>
     <MainRoutes />

    </div>
  );
}

export default App;
